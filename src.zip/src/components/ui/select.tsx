"use client";

import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import {
  Check,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

import { cn } from "@/lib/utils";

const Select = SelectPrimitive.Root;
const SelectGroup = SelectPrimitive.Group;
const SelectValue = SelectPrimitive.Value;

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.Trigger
  >
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex h-10 w-full items-center justify-between rounded-md border border-input px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary/30 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
      className
    )}
    {...props}
  >
    {children}

    <SelectPrimitive.Icon asChild>
      <ChevronDown className="h-4 w-4 opacity-50" />
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
));

SelectTrigger.displayName =
  SelectPrimitive.Trigger.displayName;

const SelectScrollUpButton = React.forwardRef<
  React.ElementRef<
    typeof SelectPrimitive.ScrollUpButton
  >,
  React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.ScrollUpButton
  >
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollUpButton
    ref={ref}
    className={cn(
      "flex cursor-default items-center justify-center py-1",
      className
    )}
    {...props}
  >
    <ChevronUp className="h-4 w-4" />
  </SelectPrimitive.ScrollUpButton>
));

SelectScrollUpButton.displayName =
  SelectPrimitive.ScrollUpButton.displayName;

const SelectScrollDownButton = React.forwardRef<
  React.ElementRef<
    typeof SelectPrimitive.ScrollDownButton
  >,
  React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.ScrollDownButton
  >
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollDownButton
    ref={ref}
    className={cn(
      "flex cursor-default items-center justify-center py-1",
      className
    )}
    {...props}
  >
    <ChevronDown className="h-4 w-4" />
  </SelectPrimitive.ScrollDownButton>
));

SelectScrollDownButton.displayName =
  SelectPrimitive.ScrollDownButton.displayName;

/**
 * Custom props for SelectContent.
 *
 * onViewportScroll is NOT a Radix SelectContent prop.
 * We add it here and forward it to the internal
 * SelectPrimitive.Viewport.
 */
interface SelectContentProps
  extends React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.Content
  > {
  onViewportScroll?: (
    event: React.UIEvent<HTMLDivElement>
  ) => void;
}

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  SelectContentProps
>(
  (
    {
      className,
      children,
      position = "popper",
      onViewportScroll,
      ...props
    },
    ref
  ) => (
    <SelectPrimitive.Portal>
      <SelectPrimitive.Content
        ref={ref}
        className={cn(
          "relative z-[9999] max-h-96 min-w-[8rem] overflow-hidden rounded-md border shadow-md bg-white",
          className
        )}
        position={position}
        {...props}
      >
        <SelectScrollUpButton />

        <SelectPrimitive.Viewport
          className={cn(
            "p-1",
            position === "popper" &&
            "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
          )}
          onScroll={onViewportScroll}
        >
          {children}
        </SelectPrimitive.Viewport>

        <SelectScrollDownButton />
      </SelectPrimitive.Content>
    </SelectPrimitive.Portal>
  )
);

SelectContent.displayName =
  SelectPrimitive.Content.displayName;

const SelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.Label
  >
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn(
      "py-1.5 pl-8 pr-2 text-sm font-semibold",
      className
    )}
    {...props}
  />
));

SelectLabel.displayName =
  SelectPrimitive.Label.displayName;

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.Item
  >
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      // Hover background
      "hover:bg-gray-100",

      // Radix highlighted state
      "data-[highlighted]:bg-gray-100",

      // Keyboard focus
      "focus:bg-gray-100",

      // Disabled
      "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </SelectPrimitive.ItemIndicator>
    </span>

    <SelectPrimitive.ItemText>
      {children}
    </SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
));

SelectItem.displayName =
  SelectPrimitive.Item.displayName;

const SelectSeparator = React.forwardRef<
  React.ElementRef<
    typeof SelectPrimitive.Separator
  >,
  React.ComponentPropsWithoutRef<
    typeof SelectPrimitive.Separator
  >
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn(
      "-mx-1 my-1 h-px bg-muted",
      className
    )}
    {...props}
  />
));

SelectSeparator.displayName =
  SelectPrimitive.Separator.displayName;

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
};














// "use client";

// import * as React from "react";
// import * as SelectPrimitive from "@radix-ui/react-select";
// import {
//   Check,
//   ChevronDown,
//   ChevronUp,
// } from "lucide-react";

// import { cn } from "./utils";

// export const Select = SelectPrimitive.Root;
// export const SelectValue = SelectPrimitive.Value;

// export const SelectTrigger = React.forwardRef<
//   React.ElementRef<typeof SelectPrimitive.Trigger>,
//   React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger>
// >(({ className, children, ...props }, ref) => (
//   <SelectPrimitive.Trigger
//     ref={ref}
//     className={cn(
//       "flex h-11 w-full items-center justify-between rounded-lg border border-gray-300 bg-white px-4 text-sm",
//       "transition-colors",
//       "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
//       "disabled:cursor-not-allowed disabled:opacity-50",
//       "[&>span]:truncate",
//       className
//     )}
//     {...props}
//   >
//     {children}

//     <SelectPrimitive.Icon asChild>
//       <ChevronDown className="h-4 w-4 text-gray-500" />
//     </SelectPrimitive.Icon>
//   </SelectPrimitive.Trigger>
// ));

// SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;

// export const SelectContent = React.forwardRef<
//   React.ElementRef<typeof SelectPrimitive.Content>,
//   React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
// >(({ className, children, position = "popper", ...props }, ref) => (
//   <SelectPrimitive.Portal>
//     <SelectPrimitive.Content
//       ref={ref}
//       position={position}
//       className={cn(
//         "relative z-[9999] max-h-80 min-w-[var(--radix-select-trigger-width)] overflow-hidden rounded-lg border border-gray-200 bg-white shadow-xl",
//         "data-[state=open]:animate-in data-[state=closed]:animate-out",
//         "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
//         "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
//         className
//       )}
//       {...props}
//     >
//       <SelectPrimitive.ScrollUpButton className="flex cursor-default items-center justify-center py-2">
//         <ChevronUp className="h-4 w-4" />
//       </SelectPrimitive.ScrollUpButton>

//       <SelectPrimitive.Viewport
//         className={cn(
//           "p-1",
//           position === "popper" &&
//             "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
//         )}
//       >
//         {children}
//       </SelectPrimitive.Viewport>

//       <SelectPrimitive.ScrollDownButton className="flex cursor-default items-center justify-center py-2">
//         <ChevronDown className="h-4 w-4" />
//       </SelectPrimitive.ScrollDownButton>
//     </SelectPrimitive.Content>
//   </SelectPrimitive.Portal>
// ));

// SelectContent.displayName = SelectPrimitive.Content.displayName;

// export const SelectItem = React.forwardRef<
//   React.ElementRef<typeof SelectPrimitive.Item>,
//   React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
// >(({ className, children, ...props }, ref) => (
//   <SelectPrimitive.Item
//     ref={ref}
//     className={cn(
//       "relative flex w-full cursor-pointer select-none items-center rounded-md py-2 pl-8 pr-3 text-sm outline-none",
//       "transition-colors",
//       "focus:bg-primary/10 focus:text-primary",
//       "data-[highlighted]:bg-primary/10",
//       "data-[highlighted]:text-primary",
//       "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
//       className
//     )}
//     {...props}
//   >
//     <span className="absolute left-2 flex h-4 w-4 items-center justify-center">
//       <SelectPrimitive.ItemIndicator>
//         <Check className="h-4 w-4 text-primary" />
//       </SelectPrimitive.ItemIndicator>
//     </span>

//     <SelectPrimitive.ItemText>
//       {children}
//     </SelectPrimitive.ItemText>
//   </SelectPrimitive.Item>
// ));

// SelectItem.displayName = SelectPrimitive.Item.displayName;